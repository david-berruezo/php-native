<?php      
require('/usr/lib/php5/sphinxapi.php');

# mysql options
$dbhost = '192.168.x.x';
$dbuser = 'sakila';
$dbpass = 'changeme';
$dbschema = 'sakila';

# connect to mysql
$dbh = new mysqli($dbhost, $dbuser, $dbpass, $dbschema);

# sphinx host and port
$host = '192.168.x.x';
$port = 9312;
# instantiate a SphinxClient object
$sphinx= new SphinxClient();
# connect to the server
$sphinx->SetServer($host, $port);
# set match mode
$sphinx->SetMatchMode(SPH_MATCH_EXTENDED2);
# set the sort mode
$sphinx->SetSortMode(SPH_SORT_ASC);

# the index to perform searches against
$search_index = 'film_dist';
# the index to build excerpts against. Cannot be a distributed index 
$excerpt_index = 'film_main';
# the search term for this example
$search_term = 'Ancient India';
# the search query
$search_query = "@description $search_term";

# perform the search
$search_results = $sphinx->Query($search_query, $search_index);

# base query, then use explode to build the IN list for film_id values
$query= 'SELECT film_id, title, description from film WHERE film_id IN ('
    .  implode(",", array_keys($search_results["matches"])) . ')';

$db_results= $dbh->query($query);


$results = array();
$docs = array();

# push each row into the $results array to maintain order
while ($row = $db_results->fetch_array())
{
  array_push($results, array('film_id'          => $row["film_id"],
    'title'            => $row["title"],
    'description'      => $row["description"]) );

  array_push($docs, $row["description"]);

}

# Note: excerpt index used for building indexes must be an on-disk index
# non-distributed index
$options= array('before_match'    => '<b>',
    'after_match'     => '</b>',
    'around'          => 3,
    'single_passage'  => 0,
    'chunk_separator' => '...',
    'limit'           => 180);

# obtain the excerpts. Notice passing $docs
$excerpts= $sphinx->BuildExcerpts($docs,
    $excerpt_index, 
    $search_term,
    $options);

for ($x= 0; $x < count($results); $x++) {
  print "<p>" . $results[$x]["title"] . "</p>\n";
  print "<p>" . $excerpts[$x] . "</p>\n";
}




?>
