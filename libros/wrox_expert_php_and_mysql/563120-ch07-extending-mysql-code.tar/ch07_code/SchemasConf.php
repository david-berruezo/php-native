<?php
$DB= '127.0.0.1';

# Drizzle connection options.
$dbHost= '127.0.0.1';
$dbUser= "root";
$dbPass= "";
$dbName= "information_schema";

?>
