<?php

# Schemas class 
# Copyright (C) 2009 Patrick Galbraith
# All rights reserved.
#
# Use and distribution licensed under the BSD license.  See
# the COPYING file in this directory for full text.

# This is a base class for schema listing utilizing the db_bytes() UDF
# It encapsulates common configuration and initialization of things 
# such as the database connection and query to obtain information 
# about schemas such as number of tables and byte count

# this contains all the globals that this application will use
require('SchemasConf.php');

class Schemas 
{
  # class member declarations
  private $mysqli;
  private $dbName;
  private $dbHost;
  private $dbUser;
  private $dbPass;
  private $_rows;
  private $_fields;
  private $_hash_result;

  #
  # constructor
  #
  public function __construct()
  {
    # obtain the connection information
    $this->dbHost= $GLOBALS['dbHost'];
    $this->dbUser= $GLOBALS['dbUser'];
    $this->dbPass= $GLOBALS['dbPass'];
    $this->dbName= $GLOBALS['dbName'];

    # connect to the database
    $this->mysqli= new mysqli($this->dbHost, 
                              $this->dbUser,
                              $this->dbPass,
                              $this->dbName);

    if ($this->mysqli->connect_error) {
      die('Connect Error (' . $mysqli->connect_errno . ') '
          . $mysqli->connect_error);
    }

  }

  # 
  # destructor 
  #
  public function __destruct()
  {
    $this->mysqli->close();
  }

  #
  # get()
  #
  # this function simply gets an array containing the result
  # set of the query that utilizes the db_bytes() UDF
  # 
  # ARGUMENTS
  #  optional schema_name, used in the where clause of the query
  #
  # RETURNS
  #  array containing the result set of the query
  #
  public function get($schema_name = null)
  {
    # the main query
    $query= <<<EOQUERY
SELECT table_schema, 
       count(*) AS num_tables, 
       db_bytes(table_schema) AS bytes 
FROM information_schema.tables
EOQUERY;

    # if schema_name set, append WHERE clause to query
    if (isset($schema_name)) {
      $query .= ' WHERE table_schema = ?';
    }
    # append GROUP BY and ORDER BY
    $query .= ' GROUP BY table_schema ORDER BY table_schema';

    # initialize the statement
    $stmt= $this->mysqli->stmt_init();

    # prepare the query
    if ($stmt->prepare($query)) {
      # bind the single placeholder if $schema_name set
      if (isset($schema_name)) {
        $stmt->bind_param("s", $schema_name);
      }
    }

    # execute the statement
    $stmt->execute();

    # obtain the fields to bind to
    $this->get_fields($stmt);
 
    # set an array to bind to for the result set
    call_user_func_array(array($stmt, 'bind_result'), $this->_fields); 

    # fetch all the rows
    $this->fetchall_hash_result($stmt);

    # close the statement
    $stmt->close();

    return $this->_hash_result;
  }

  #
  # get_fields()
  #   a method to obtain field names, storing in class member
  #   _fields
  # 
  # ARGS
  #   $stmt - prepared statement
  #
  private function get_fields(&$stmt) {
    $metadata= $stmt->result_metadata();
    while ($field = $metadata->fetch_field()) {
      $this->_fields[] = &$this->_row[$field->name];
    }
    $metadata->close();

  }

  #
  # fetchall_hash_result()
  #   a method to obtain the result of the executed prepared statement
  #   storing the result as a hash/associative array the class member 
  #   _hash_result
  # 
  # ARGS
  #   $stmt - prepared statement
  #
  private function fetchall_hash_result(&$stmt) {
    call_user_func_array(array($stmt, 'bind_result'), $this->_fields); 

    while ($stmt->fetch() ) {
      foreach($this->_row as $field => $val) {
        $tmp_ar[$field]= $val;
      }
      $this->_hash_result[] = $tmp_ar;
    }
  }
}

?>
