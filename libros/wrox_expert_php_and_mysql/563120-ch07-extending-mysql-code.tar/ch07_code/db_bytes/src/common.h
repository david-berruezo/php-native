#define VERSION_STRING "0.1\n"
#define VERSION_STRING_LENGTH 4

#define DIR_PATH_LENGTH 255

#define RESULT_LENGTH sizeof(char) * 12;

