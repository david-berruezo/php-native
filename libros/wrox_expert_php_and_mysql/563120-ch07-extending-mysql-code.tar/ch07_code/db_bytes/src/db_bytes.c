/* Copyright (C) 2009 Patrick Galbraith

  See COPYING file found with distribution for license.

*/

#include <mysql.h>
#include <string.h>

#include <stdio.h>
#include <stdlib.h>

#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <dirent.h>
#include <stdint.h>

#include "common.h"

/*
  this variable contains the directory path of datadir
  as read by MySQL, usually a relative path to the server
*/
extern char *mysql_data_home;

/* init function */
my_bool db_bytes_init(UDF_INIT *initid, UDF_ARGS *args, char *message);

/* value function */
char *db_bytes(UDF_INIT *initid, UDF_ARGS *args, char *result, unsigned long *length, char *is_null, char *error);

/* de-init function */
void db_bytes_deinit(UDF_INIT *initid);

/* 
  db_bytes_init

  Checks the number of arguments passed to the UDF and returns an error if
  not exactly one argument

  Also, memory is allocated for string result returned in value function 
  db_bytes() which must be freed in db_bytes_init()

  ARGUMENTS:
         UDF_INT *initid 
           UDF_INIT pointer which can be used to make 
           allocated memory availble to the other functions

         UDF_ARG *args
           UDF_ARG pointer to the UDF arguments, which includes
           the argument lengths and types

         char *message
           String for setting errors

  RETURNS boolean value, 0 success, 1 failure 


*/
my_bool db_bytes_init(UDF_INIT *initid,
                      UDF_ARGS *args, 
                      char *message)
{
  char *total_bytes;

  /*
    check the number of arguments and if a string and if not only one,
    return an error
  */
  if (args->arg_count != 1 || args->arg_type[0] != STRING_RESULT)
  {
    /*
      copy a useful message to the char pointer *message 
      this will be returned to the user
    */
    strncpy(message, " USAGE: db_bytes('<schema>').", MYSQL_ERRMSG_SIZE);
    return 1;
  }

  /*
    allocated a character sequence (string) pointer
    this will be used for the results in the value
    function, db_bytes()
  */
  total_bytes = malloc(sizeof(char) * 12);

  /* test block for debugging - this will segfault if 
    argument is from result set */
  /*if (strcmp("test", args->args[0])) {
    fprintf(stderr, "matches: %s\n", args->args[0]);
  }
  */
  /*
    coerce the single argument to a string
  */
  args->arg_type[0]= STRING_RESULT;

  /*
    initid can be used in _init to point to allocated memory for use
    in the value function. This must be freed in _deinit
  */
  initid->ptr= (char *)total_bytes;

  /*
    return of 0 is success
  */
  return 0;
}

/*
  db_bytes()

  This is the value function that given a schema name argument (string) it then
  obtains the number of bytes of all files in a MySQL schema subdirectory, then that
  value is stored in the return string and returned to the user

  ARGUMENTS:
         UDF_INT *initid
           UDF_INIT pointer which can be used to make
           allocated memory availble to the other functions

         UDF_ARG *args
           UDF_ARG pointer to the UDF arguments, which includes
           the argument lengths and types

        *result
          Unused

        *length
          Pointer, specifies the length of the return value

        *is_null
          Set to true, denotes that the value being returned
          is NULL

        *error
           if set to 1 the function will not be
           not called anymore and mysqld will return NULL
           for all calls to this copy of the function.

        RETURNS
          string pointer
*/
char *db_bytes(UDF_INIT *initid,
               UDF_ARGS *args,
               char *result,
               unsigned long *length,
                char *is_null,
                char *error)
{
  /*
    set a char pointer to point to the memory allocated
    in db_bytes_init() for storing the result
  */
  char *total_bytes= (char *)initid->ptr;

  /* for return values from functions */
  int retval;
  /*
    the variable containing the sum of file sizes
  */
  uint64_t total_size= 0;

  /*
    for printing errors to which you then pass to stderr
  */
    char errstr[255];

  /*
    pointer to the directory, when opened
  */
  DIR *pdir;

  /*
    character sequence/array for appending directory path to
  */
  char schema_path[DIR_PATH_LENGTH]= "";

  /*
    pointer to current directory entry
  */
  struct dirent *pdirent;

  /*
    stat structure for obtaining the status of the current directory
    entry
  */
  struct stat fstats;

  /*
    return a NULL if information_schema , but not an error
  */
  if (!strcasecmp("information_schema", args->args[0]))
  {
    /*
      setting is_null and returning NULL ensures a NULL is returned
      in MySQL
    */
    *is_null= 1;
    *length= 0;
    return (char *)NULL;
  }

  /*
    start off concatentating the datadir value set in mysql_data_home
  */
  strncat(schema_path, mysql_data_home, strlen(mysql_data_home));
  /* need to add a delimiter */
  strncat(schema_path, "/", 1);
  /* now add the schema name */
  strncat(schema_path, args->args[0], args->lengths[0]);
  strncat(schema_path, "/", 1);

  /* stat the schema_path value  */
  retval= lstat(schema_path, &fstats);
  /*
    if -1 is the return value, print an error to the error log
    and return null
  */
  if (retval == -1) {

    sprintf(errstr, "ERROR with schema '%s': (%s)\n",
            args->args[0], strerror(errno));

    fprintf(stderr, "%s\n\n", errstr);
    *length= 0;
    /* *length= strlen(errstr); */
    /* return tmp_errstr; */
    *is_null= 1; 
    return (char *)NULL;
  }

  /* open the directory */
  pdir= opendir(schema_path);

  /*
    if the pointer is null, then there was a problem
    so return an error
  */
  if (pdir == NULL) {
    sprintf(errstr, "ERROR with schema '%s': (%s)\n",
            args->args[0], strerror(errno));
    fprintf(stderr, "%s\n\n", errstr);
    *length= 0;
    *is_null= 1;
    return (char *)NULL;
  }

  /*
    read the first directory entry
  */
  pdirent= readdir(pdir);

  /*
    in a while loop, continue to read directory entries, summing of the 
    directory entry sizes
  */
  while (pdirent != NULL) {
    /* buffer for appending directory entries to */
    char path_buf[DIR_PATH_LENGTH] = "";

    /* we do not care about reading . or .. */
    if (! strcmp(pdirent->d_name, ".") || ! strcmp(pdirent->d_name, ".."))
    {
      pdirent= readdir(pdir);
      continue;
    }

    /* start out concatenating the schema path */ 
    strncat(path_buf, schema_path, strlen(schema_path));

    /* add the entry - file or directory name */
    strncat(path_buf, pdirent->d_name, pdirent->d_reclen);

    /* stat the entry - file or directory */
    retval= lstat(path_buf, &fstats);

    /*
      directory entries have a size too, so add to total
    */
    total_size+= fstats.st_size;

    /* rinse, lather, repeat - read the next entry */
    pdirent= readdir(pdir);
  }
  /* all done now, so close the directory */
  closedir(pdir);

  /*
    need to return a string, so use sprintf to convert the total_size
    to a string value contained in total_bytes
  */
  sprintf(result, "%d", total_size);

  /*
    length MUST be set for the UDF to properly return the value
  */
  *length= strlen(result);

  /* now return the string */
  return (result);
}

/* de-init function */
void db_bytes_deinit(UDF_INIT *initid)
{
  char *total_bytes= initid->ptr;

  /* free the allocated memory */
  free(total_bytes);

  return;
}
