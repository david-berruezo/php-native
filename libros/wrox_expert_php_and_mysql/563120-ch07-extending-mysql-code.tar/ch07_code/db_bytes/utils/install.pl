#!/usr/bin/perl

# Simple script (for now) to run against the LibCurl UDFs

use strict;
use Getopt::Long;
use DBI;
use Data::Dumper;
use Carp qw(croak);

our $opt_debug;
our $opt_verbose;
our $opt_host;
our $opt_schema;
our $opt_user;
our $opt_password;
our $opt_silent;
our $opt_help;

GetOptions (
    'd|debug'       => \$opt_debug,
    'h|host=s'      => \$opt_host,
    'h|help'        => \$opt_help,
    'p|password=s'  => \$opt_password,
    's|silent'      => \$opt_silent,
    'u|user=s'      => \$opt_user,
    'v|verbose'     => \$opt_verbose,
) or usage();

usage() if $opt_help;

my $funclist = {
    du_schema_mb    => 'STRING',
    du_schema_bytes => 'STRING',
};

my $types = { 
    0 => 'STRING',
    2 => 'INT',
};


$opt_schema ||= 'test';
$opt_user   ||= 'root';
$opt_host   ||= 'localhost';
my $existing_functions;

my $dbh= DBI->connect("DBI:mysql:$opt_schema", $opt_user, $opt_password) 
    or croak "Unable to connect! $DBI::errstr\n";

my $sth= $dbh->prepare('select name,ret from mysql.func') 
    or croak "Unable to fetch functions! $DBI::errstr\n";
$sth->execute();

my $ref= $sth->fetchall_arrayref();
$sth->finish();
map {$existing_functions->{$_->[0]} = $types->{$_->[1]}} @$ref; 

for my $func(keys %$funclist) {
    my $ans= '';
    unless ($existing_functions->{$func}) {
        print "function $func doesn't exist.";
        unless ($opt_silent) {
            print " Create? [Y|n]\n";
            $ans= <STDIN>;
            chomp($ans);
        } 
        else {
            $ans= 'Y';
        }
        if ($ans eq 'Y' or $ans eq 'y') {
            my $create= 'CREATE FUNCTION ' . $func . 
                ' RETURNS ' . $funclist->{$func} .
                " SONAME 'os_functions_mysql.so'"; 
            print "Running: $create\n";
            $sth= $dbh->prepare($create);
            $sth->execute() or croak "Error: $DBI::errstr\n";
        }

    }
    else {
        print "function $func does exist\n";
    }
}

sub usage {
    my ($msg)= @_;
    print "ERROR: $msg\n\n";
    print <<EOUSAGE;
    d|debug             Debug flag 
    h|host=s            Host  
    p|password=s        Password 
    s|silent=s          Silent - please don't ask me, just do it! 
    u|user=s            DB Username 
    v|verbose           Verbosity 

EOUSAGE

    exit(0);
}
1;
