<?php

function rand_str($len = 16)
{
    $chars_len = (strlen($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890') - 1);

    $str = ''; 
   
    for ($i = 1; $i <= $len; $i++) {
        $rand_char = $chars{rand(0, $chars_len)};
       
        if ($rand_char != $str{$i - 1}) { 
          $str .=  $rand_char;
        }
        else {
          $i--;
        }
    }
   
    return $str;
}

# setting id 'mymemc'
$memc = new Memcached('mymemc');

# prefix every item key with "myapp:"
$memc->setOption(Memcached::OPT_PREFIX_KEY, "myapp:");

# set server distribution to consistent hashing
$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);

# two servers in the pool
$servers = array (
array ('192.168.1.106', 11211),
array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

// set a value
for ($i = 1; $i <= 5; $i++) {
  $key = "t$i";
  if ($memc->set($key, "$i: some value")) {
    // if true, success setting  
    echo "t$i was set.\n";
  }
  else {
    // if falsed, failed to set
    echo "failed to set t$i\n";
  }
}

$memc->getDelayed(array ('t1','t2','t3'), true, 'print_item');

if ($memc->getDelayed(array ('t1','t2','t3'), true)) {

  echo "mget successful.\n";
  $result = array();

  while ($result = $memc->fetch()) {
    echo "key: " . $result["key"] .
      " value: '" . $result["value"] .
      "' cas: " . $result["cas"] . "\n";
  }
}
elseif ($memc->getResultCode() == Memcached::RES_NOTSTORED) {
  echo "error : NOT STORED\n";
}

