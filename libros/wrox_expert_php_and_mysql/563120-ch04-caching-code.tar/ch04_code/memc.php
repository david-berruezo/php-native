<?php

function rand_str($len = 16)
{
    $chars_len = (strlen($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890') - 1);

    $str = ''; 
   
    for ($i = 1; $i <= $len; $i++) {
        $rand_char = $chars{rand(0, $chars_len)};
       
        if ($rand_char != $str{$i - 1}) { 
          $str .=  $rand_char;
        }
        else {
          $i--;
        }
    }
   
    return $str;
}

# setting id 'mymemc'
$memc = new Memcached('mymemc');

# prefix every item key with "myapp:"
$memc->setOption(Memcached::OPT_PREFIX_KEY, "myapp:");

# set server distribution to consistent hashing
$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);

# two servers in the pool
$servers = array (
array ('192.168.1.106', 11211),
array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

// set a value
if ($memc->set('t1', 'some value')) {
  // if true, success setting  
  echo "t1 was set.\n";
}
else {
  // if falsed, failed to set
  echo "failed to set t1\n";
}


// now fetch t1
$t1= $memc->get('t1');

$result_code= $memc->getResultCode;
if ($result_code == Memcached::RES_SUCCESS) {
  print "t1 is $t1\n";
}
elseif ($result_code == Memcached::RES_NOTFOUND) {
  print "t1 not found\n";
}

if ($val = $memc->get('t2')) {
  if ($memc->replace('t2', 'replaced value')) {
    echo "replaced t2's value\n";
  }
  else {
    echo "failed to replace t2's value\n";
  }
} 
else {
  if ($memc->add('t2', 'added value')) {
    echo "added t2's value\n";
  }
  else {
    echo "failed to add t2's value\n";
  }
}

if ($memc->set('t3', 'this will expire in 6 seconds', 6)) {
  $i = 0;
  while(1) {
    if ($val = $memc->get('t3')) {
      echo "\$val (t3) still exists after $i seconds.\n";
      sleep(1);
      $i++;
    }
    else {
      echo "\$val (t3) has expired after $i seconds.\n";
      break;
    }
  }
}


$t2s_value = $memc->get('t2');

echo "t2's value: $t2s_value\n";

// arbitrary list of server keys
$server_keys = array('serverA', 'serverB', 'serverC');
// loop through for each server key
foreach ($server_keys as $server_key) {
  // loop through, assigning 
  for ($i = 0; $i < 4; $i++) {
    // use a random string for the key
    $key = "$server_key:" . rand_str(8);
    $key_list[$server_key][] = $key; 
    $memc->setByKey($server_key, $key, "value for $key");
  }
}

// loop through list of server keys
foreach ($server_keys as $server_key) {
  // loop through each key per server
  foreach ($key_list[$server_key] as $key) {
    $value= $memc->getByKey($server_key, $key);
    echo "$server_key: $key : $value\n";
  }
}

// you can also store objects serialized, array in this example
$memc->set('server_keys', $server_keys);

// get object, de-serialized
$copy_of_server_keys = $memc->get('server_keys');

print_r($copy_of_server_keys);

$memc->delete('t1');

if ($memc->set('counter', 1)) {
  echo $memc->increment('counter') . "\n";
  echo $memc->increment('counter', 10) . "\n";
  echo $memc->decrement('counter') . "\n";
  echo $memc->decrement('counter', 5) . "\n";
}

?>
