<?php

class User {

	static $userAttribs = array(
		'uid',
		'username',
		'firstname',
    'lastname',
		'password',
		'email',
    'address',
    'city',
    'state',
    'age',
    'zip',
	);

  private $dbh, $memc;

	private $uid, $username, $firstname, $lastname, $password, $email,
		$address, $city, $state, $age;

	private $_user_loaded;

  public function __construct( $uid = 0, $username = '') {

    $this->uid = intval($uid);
    $this->username = $username;

    // database connection
    $this->dbh = new mysqli('localhost', 'wrox', 'wr0x', 'wrox');

    // handle error connecting
    if (mysqli_connect_errno() != 0) {
      printf("Can't connect to MySQL Server. Errorcode: %s\n", mysqli_connect_error());
      exit;
    } 

    if (!$this->dbh) {
      printf("Can't connect to MySQL Server. Errorcode: %s\n", mysqli_connect_error());
      exit;
    } 

    // memcached server pool connection
    $serverlist = array (array ('localhost', 11211));
    
    $this->memc = new Memcached();
    $this->memc->AddServers($serverlist);

    $this->load();
  }

	/**
	 * Load the user from either cache or database 
	 */
  public function load() {
    if ( $this->_user_loaded ) {
      return true;
    }

    // get the UID from the database
    if (!$this->uid) {
      $this->uid = $this->uidFromName($this->username);
    }
    // still no UID, this is a new user
    if (!$this->uid) {
      $this->loadNewUser( $this->username);
    } 

    // if user is in cache
    if( ! $this->getFromCache()) {
      // if user wasn't in DB, return false
      if (! $this->getFromDB()) {
        // set to avoid loading what need not be loaded 
        return false;
      }
      // if user was in DB, read-through cache
      else {
        $this->setToCache();
        return true;
      }
    }
    return true;
	}

	/**
	 * factory method for creation from a given user ID.
	 */
	private function newFromId( $uid ) {
		$user = new User;
		$user->uid = $uid;
		$user->user_from = 'id';
		return $user;
	}

  private function getFromCache() {
    $key = "user:$this->uid";
    $user = $this->memc->get($key);
    if ($user) {
      // set object attribs from $user fetched
      foreach (self::$userAttribs as $attrib) {
        print "$attrib $user[$attrib]\n";
        $this->$attrib = $user[$attrib];
      }
      $this->_user_loaded  = true;
      return true;
    }
    else {
      return false;
    }
  }

  private function setToCache() {
    $key = "user:$this->uid";
    $user = array(); 
    // set $user array with each attrib for object 
    foreach (self::$userAttribs as $attrib) {
      $user[$attrib] = $this->$attrib;
    }

    // use return value of set
    return ($this->memc->set($key, $user));

  }

/*
  delete user from cache
*/
  private function deleteFromCache() {
    $key = "user:$this->uid";
    // use return value of set
    return ($this->memc->delete($key));
  }

	/**
	 * Get the real name of a user given their user ID
	 *
	 */
	private function getFromDB() {

		$query = 'SELECT uid,username,email,firstname,lastname,age,address,city,';
    $query .= 'state,zip FROM users WHERE uid = ?';

		$sth = $this->dbh->prepare($query);
    // if the statement was not prepared
    if (!$sth) {
      // print error if not
      if ($this->dbh->errno) {
        print "Error: " . $this->dbh->error . "\n";
      }
      // return false
      return false;
    }

    $sth->bind_param('i', $this->uid);

    $sth->execute();

    $sth->store_result();

    // if user was not fetched, return false
    if (! $sth->num_rows) {
      print "user not found.\n";
      return false;
    }

    $sth->bind_result($this->uid, $this->username, $this->email, 
                      $this->firstname,$this->lastname,$this->age,
                      $this->address,$this->city,$this->state,$this->zip);
    $sth->fetch();
    $sth->close();
    $this->_user_loaded = true;
    return true;
	}

  public function save() {
    if ($this->uid) {
      $this->update();
    }
    else {
      $this->insert();
    }
    $this->setToCache();
  }
	/**
	 * Get database id given a user name
	 * @param $name \string Username
	 * @return \types{\int,\null} The corresponding user's ID, or null if user is nonexistent
	 */
	private function uidFromName( $username) {
		$query = 'SELECT uid FROM users WHERE username = ?';

		$sth = $this->dbh->prepare($query);

    $sth->bind_param('s', $this->username);
    $sth->execute();

    $sth->bind_result($this->uid);
    $sth->fetch();
    $sth->close();
	}

	/**
	 */
	static function randomPassword() {
		global $min_pass_len;
		$pwchars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz';
		$l = strlen( $pwchars ) - 1;

		$pwlength = max( 7, $min_pass_len );
		$digit = mt_rand(0, $pwlength - 1);
		$np = '';
		for ( $i = 0; $i < $pwlength; $i++ ) {
			$np .= $i == $digit ? chr( mt_rand(48, 57) ) : $pwchars{ mt_rand(0, $l)};
		}
		return $np;
	}

	/**
	 * Set cached properties to default. 
	 */
	function loadNewUser( $username = false ) {

		$this->id = 0;
		$this->username = $username;
		$this->firstname = '';
		$this->lastname = '';
		$this->password = '';
		$this->email = '';

	}

  /** 
   * Load user data from the database.
   *
   */
  function loadFromDatabase() {
    # Paranoia
    $this->uid = intval( $this->uid);

    /** Anonymous user */
    if ( !$this->id ) {
      $this->loadNewUser();
      return false;
    }

    $row = $this->dbh->selectRow( 'user', '*', array( 'uid' => $this->uid));


    if ( $row !== false ) {
      # Initialise user table data
      $this->loadFromRow($row);
      $this->getEditCount(); // revalidation for nulls
      return true;
    } 
    else {
      # Invalid uid 
      $this->uid = 0;
      $this->loadNewUser();
      return false;
    }
  }

	/**
	 * Initialize this object from a row from the user table.
	 */
	function loadFromRow( $row ) {
		$this->_user_loaded = true;

		if ( isset( $row->uid) ) {
			$this->uid = intval( $row->uid);
		}
		$this->username   = $row->username;
		$this->password   = $row->password;
		$this->firstname  = $row->firstname;
		$this->lastname   = $row->lastname;
		$this->age        = $row->age;
		$this->address    = $row->address;
		$this->city       = $row->city;
		$this->state      = $row->state;
		$this->zip        = $row->zip;
		$this->email      = $row->email;
	}

	/**
	 * Get the user name, or the IP of an anonymous user
	 */
	function getUserName() {
			$this->load();
			return $this->username;
  }

	 /**
	 */
	function setUserName($str) {
		$this->load();
		$this->username = $str;
	}

	/**
	 * Set the password for a password reminder or new account email
	 */
	function setPassword( $str) {
		$this->load();
		$this->password = self::crypt( $str );
	}

	/**
	 * Get the user's e-mail address
	 */
	function getEmail() {
		$this->load();
		return $this->email;
	}

	/**
	 * Set the user's e-mail address
	 */
	function setEmail( $str ) {
		$this->load();
		$this->email = $str;
	}

	/**
	 * Get the user's real name
	 */
	function getFirstName() {
		$this->load();
		return $this->firstname;
	}

	/**
	 * Set the user's real name
	 */
	function setFirstName ($str) {
		$this->load();
		$this->firstname = $str;
	}
	 /**
	 * @note User::newFromName() has rougly the same function, when the named user
	 * does not exist.
	 */
	function setAge($str) {
		$this->load();
		$this->age= $str;
	}
	function getAge() {
		$this->load();
		return $this->age;
	}
	function setCity($str) {
		$this->load();
		$this->city= $str;
	}
	function getCity() {
		$this->load();
		return $this->city;
	}
	function setState($str) {
		$this->load();
		$this->state = $str;
	}
	function getState() {
		$this->load();
		return $this->state;
	}
	function setZip($str) {
		$this->load();
		$this->zip= $str;
	}
	function getZip() {
		$this->load();
		return $this->zip;
	}
	function setAddress($str) {
		$this->load();
		$this->address = $str;
	}
	function getAddress() {
		$this->load();
		return $this->address;
	}


	function getUID () {
    $uid = 0;
		$uid = $this->dbh->selectCol( 'user', 'user_id', array( 'user_name' => $s ));
		return $uid;
	}

	function insert() {
    $this->load();
    $newuser = array(
                    username  => $this->username,
                    email     => $this->email,
                    age       => $this->age,
                    firstname => $this->firstname,
                    lastname  => $this->lastname,
                    address   => $this->address,
                    city      => $this->city,
                    state     => $this->state,
                    zip       => $this->zip,
                    uid       => $this->uid );

    $insert = 'INSERT INTO users ';
    $insert .= '(username, email, age, firstname, lastname, address, city, state, zip)';
    $insert .= 'WHERE uid = ?';
    $sth = $this->dbh->prepare($insert);
    $sth->bind_param('ississssssi', $newuser); 
   
    $sth->execute();
    $sth->close();
    $this->uid = $this->dbh->insert_id;
    return true;
	}

	/**
	 * Add this existing user object to the database
	 */
	function update() {
    $bind_vals = array();

    $this->load();

    $update = 'UPDATE users SET email = ?, age = ?, firstname = ?, lastname = ?,';
    $update .= ' address = ?, city = ?, state = ?, zip = ? WHERE uid = ?';

    $sth = $this->dbh->prepare($update);
    $sth->bind_param('sissssssi', $this->email, $this->age, $this->firstname, 
                                  $this->lastname, $this->address, $this->city,
                                  $this->state, $this->zip, $this->uid);
   
    $sth->execute();
    $sth->close();
	}

	/**
	 * delete existing user object from the database
	 */
	function delete () {

    $this->load();

    $delete = 'DELETE FROM users WHERE uid = ?';

    $sth = $this->dbh->prepare($delete);
    $sth->bind_param('i', $this->uid);
   
    $sth->execute();

    $rows = $sth->affected_rows;

    $sth->close();

    // delete from cache
    $this->deleteFromCache();

    return $rows ? true : false;
	}



	function getMaxID() {
		static $res; // cache

		if (isset($res))
			return $res;
		else {
			return $res = $this->dbh->selectField('user', 'max(user_id)', false);
		}
	}
}
