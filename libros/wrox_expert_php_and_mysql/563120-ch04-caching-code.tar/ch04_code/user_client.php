<?php

require "User.php";

// instantiate with uid 12345
$user = new User(12345);

print "age: " . $user->getAge() . "\n";
print "email: " . $user->getEmail() . "\n";
print "current address: " . $user->getAddress() . "\n";
print "city: " . $user->getCity() . "\n";
print "state: " . $user->getState() . "\n";
print "zip: " . $user->getZip() . "\n";

// change email address
$user->setEmail("patg@northscale.com");

// why not shave off a decade or so?! 
$user->setAge(30);

// move to Portsmouth, NH
$user->setCity("Portsmouth");
$user->setAddress("33 Concord St.");
$user->setZip("03801");

// write data
$user->save();

// verify it was saved!
print "age: " . $user->getAge() . "\n";
print "email: " . $user->getEmail() . "\n";
print "current address: " . $user->getAddress() . "\n";
print "city: " . $user->getCity() . "\n";
print "state: " . $user->getState() . "\n";
print "zip: " . $user->getZip() . "\n";

?>

